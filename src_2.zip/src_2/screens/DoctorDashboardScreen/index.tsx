import React from "react";
import { View, Text, FlatList } from "react-native";
import { styles } from "./styles";

import AppointmentCard from "../../components/AppointmentCard";

const appointments = [
  { id: "1", patient: "João Silva", time: "09:00" },
  { id: "2", patient: "Maria Souza", time: "10:30" },
];

const DoctorDashboardScreen: React.FC = () => {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Consultas de Hoje</Text>
      <FlatList
        data={appointments}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => <AppointmentCard appointment={item} />}
      />
    </View>
  );
};

export default DoctorDashboardScreen;
