import React from "react";
import { View, Text } from "react-native";
import { styles } from "./styles";

interface Appointment {
  id: string;
  patient: string;
  time: string;
}

const AppointmentCard: React.FC<{ appointment: Appointment }> = ({ appointment }) => {
  return (
    <View style={styles.card}>
      <Text style={styles.patient}>{appointment.patient}</Text>
      <Text style={styles.time}>{appointment.time}</Text>
    </View>
  );
};

export default AppointmentCard;
