import { StyleSheet } from "react-native";

export const styles = StyleSheet.create({
  card: {
    padding: 12,
    marginBottom: 10,
    backgroundColor: "#f9f9f9",
    borderRadius: 8,
    borderWidth: 1,
    borderColor: "#ddd",
  },
  patient: { fontSize: 16, fontWeight: "500" },
  time: { fontSize: 14, color: "#555" },
});
