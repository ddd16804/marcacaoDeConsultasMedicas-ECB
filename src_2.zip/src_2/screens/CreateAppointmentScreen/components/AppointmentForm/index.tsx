import React from "react";
import { View, Text, TextInput, Button } from "react-native";
import { styles } from "./styles";

const AppointmentForm: React.FC = () => {
  return (
    <View style={styles.container}>
      <Text style={styles.label}>Paciente:</Text>
      <TextInput style={styles.input} placeholder="Digite o nome" />

      <Text style={styles.label}>Data:</Text>
      <TextInput style={styles.input} placeholder="DD/MM/AAAA" />

      <Button title="Salvar" onPress={() => {}} />
    </View>
  );
};

export default AppointmentForm;
