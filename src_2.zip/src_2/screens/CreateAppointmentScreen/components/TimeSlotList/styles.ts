import { StyleSheet } from "react-native";

export const styles = StyleSheet.create({
  container: { marginTop: 20 },
  header: { fontSize: 18, marginBottom: 8 },
  item: {
    padding: 12,
    borderWidth: 1,
    borderColor: "#ddd",
    borderRadius: 6,
    marginBottom: 6,
  },
});
