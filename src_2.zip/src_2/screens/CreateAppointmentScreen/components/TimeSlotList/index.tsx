import React from "react";
import { View, Text, FlatList, TouchableOpacity } from "react-native";
import { styles } from "./styles";

const times = ["08:00", "09:00", "10:00", "11:00"];

const TimeSlotList: React.FC = () => {
  return (
    <View style={styles.container}>
      <Text style={styles.header}>Horários disponíveis</Text>
      <FlatList
        data={times}
        keyExtractor={(item) => item}
        renderItem={({ item }) => (
          <TouchableOpacity style={styles.item}>
            <Text>{item}</Text>
          </TouchableOpacity>
        )}
      />
    </View>
  );
};

export default TimeSlotList;
