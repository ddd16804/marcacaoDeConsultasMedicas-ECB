import React from "react";
import { View, Text } from "react-native";
import { styles } from "./styles";

import AppointmentForm from "../../components/AppointmentForm";
import TimeSlotList from "../../components/TimeSlotList";

const CreateAppointmentScreen: React.FC = () => {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Criar Agendamento</Text>
      <AppointmentForm />
      <TimeSlotList />
    </View>
  );
};

export default CreateAppointmentScreen;
